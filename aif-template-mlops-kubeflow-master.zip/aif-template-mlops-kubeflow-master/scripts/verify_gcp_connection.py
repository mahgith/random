import os
from google.cloud import storage
from vertex.common.core.logger import get_logger

def verify_gcp_connection():
    """
    Small connectivity check for GCP Cloud Storage.

    Notes:
        This script requires `PROJECT_ID` to be set in the environment and valid Application 
        Default Credentials (ADC). It validates access by listing Cloud Storage buckets and 
        prints a concise result.
    """
    # Initialize the application structured logger
    logger = get_logger("verify-gcp-connection")

    try: 
        
        project_id = os.getenv("PROJECT_ID") 

        if not project_id:
            logger.error("❌ PROJECT_ID not found in environment.")
            return
        
        storage_client = storage.Client(project=project_id)
        logger.info("🔍 Checking connection.", project=project_id)
        buckets = list(storage_client.list_buckets())
        logger.info("✅ Successful connection.", buckets_found=len(buckets))
    except Exception as e:
        logger.error("❌ Connection failed. ", error=e)

if __name__ == "__main__":
    verify_gcp_connection()