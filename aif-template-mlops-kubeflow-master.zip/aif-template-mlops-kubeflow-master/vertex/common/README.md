# Common — Shared Utilities & Cross‑Cutting Helpers

This folder contains **reusable, framework‑agnostic utilities** that multiple components and pipelines depend on (configuration, logging, parameter loading, small helpers).

> ℹ️ **Goal**<br/>
> Keep business logic inside `vertex/components/*`. Put here only **shared, generic** code that is stable and broadly useful across the project.

> 🔗 **How it’s used from Docker**<br/>
> Base/overlay images copy selected modules from `vertex/common/core/` into the image (see `vertex/docker/base/Dockerfile`).  
> Components then import them at runtime via `PYTHONPATH=/app`.

---

## 📂 Suggested structure

```bash
vertex/
└── common/
    └── core/
        ├── helper.py          # Small, generic helpers (I/O, paths, timers, etc.)
        ├── load_kfp_params.py # YAML parameter loader & helpers for KFP/Vertex
        ├── logger.py          # structlog configuration & logger factory
        └── settings.py        # Pydantic/Pydantic-Settings app config (env/ADC)
```
Add additional subpackages (e.g., `common/bq/`, `common/gcs/`) when a domain grows,
but avoid coupling to a single component.

## 🧭 Design principles

- **Small & stable API:** minimize breaking changes; document them if unavoidable.
- **No secrets**: never hard‑code credentials; read from env or Secret Manager by name.
- **Pure Python:** avoid heavy/cloud SDK dependencies unless clearly shared by many components.
- **Separation of concerns**: keep KFP‑specific code in components; generic utilities here.
- **Testable:** utilities should be unit‑testable with small fixtures.

##  Quick reference (modules)
- **settings.py** — Centralized configuration (env vars, project/region, bucket, timeouts).
Recommended to expose a single accessor (e.g., get_settings() or Settings()).
- **logger.py** — structlog setup and get_logger(name) helper for consistent JSON logs.
- **load_kfp_params.py** — YAML parameter loader (local path or gs://…) and helpers to map sections to component arguments.
- **helper.py** — Misc utilities (e.g., path joiners, safe mkdir, timing decorators).

### 🧩 Usage examples
```python
from common.core.logger import get_logger

    # Initialize the application structured logger
    logger = get_logger("training-tuning-task")

    # Bind context variables for GCP Cloud Logging
    structlog.contextvars.bind_contextvars(project_id=project_id)

    logger.info("Evaluating combinations of hyperparameters.", numbers_of_combination=len(combinations))
```

## 🔗 Cross‑references

- [Parameters](../parameters/README.md): How components are configured
- [Components](../pipelines/README.md): How components are organized
- [Pipelines](../pipelines/README.md): How components are orchestrated
- [Docker images](../docker/README.md): How components run