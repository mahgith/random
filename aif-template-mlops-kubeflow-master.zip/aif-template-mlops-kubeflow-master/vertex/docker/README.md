# Docker — Images for Vertex Pipeline Components

This folder contains the **Docker build context, Dockerfiles, and helper Makefiles** to produce the container images used by pipeline components.

- Each component should reference one of these images via KFP’s `base_image=...`.
- We keep a **single heavy base image** and layer **light, purpose‑specific images** on top to minimize overall storage and pull time.

> ℹ️ **Relationship with `common/`**
> If a component needs shared utilities, copy them into the image from `vertex/common/core/` (or another `common` subfolder).  
> This avoids re‑installing local packages dynamically and guarantees reproducible builds.

---

## 📂 Folder structure (convention)

```bash
vertex/
└── docker/
    ├── base/
    │   ├── Dockerfile         # Base image for most components
    │   ├── requirements.txt   # Core, shared Python deps (heavier set)
    │   ├── version.yaml       # Tags to publish (e.g., latest, 0.1.72)
    │   ├── Makefile           # build/release targets (uses version.yaml tags)
    │   └── .dockerignore
    └── <component-image>/
        ├── Dockerfile         # Small overlay image; builds FROM base
        ├── requirements.txt   # Extra deps needed by this component only
        ├── version.yaml
        ├── Makefile
        └── .dockerignore
```

## Naming rules

- Use short, descriptive directory names (e.g., ml-training, ingestion, ops-monitor).
- All component images should FROM the base image to keep only one heavy layer across the fleet.


## 🧱 Base image (reference)
This is the canonical base used by most pipeline components. It pins Python 3.12 and installs shared, heavier dependencies once.

vertex/docker/base/Dockerfile
```bash
FROM python:3.12-slim

# Send logs to stdout and avoid .pyc files
ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1

RUN apt-get update && apt-get upgrade -y && \
    apt-get install -y --no-install-recommends ca-certificates && \
    apt-get clean && rm -rf /var/lib/apt/lists/*

# Working directory
WORKDIR /app

# Install core dependencies
COPY docker/base/requirements.txt .
RUN pip install --no-cache-dir --upgrade pip && \
    pip install --no-cache-dir -r requirements.txt

# Copy shared library code (read-only vendor copy)
COPY common/core/ /app/common/core

# Ensure shared code is importable
ENV PYTHONPATH="/app"
```
vertex/docker/base/requirements.txt
```bash
structlog==25.5.0
pydantic==2.12.5
pydantic-settings==2.13.0
pyyaml==6.0.3
pandas==3.0.0
numpy==2.4.2
db-dtypes==1.4.4
fsspec==2026.2.0
gcsfs==2026.2.0
google-cloud-bigquery[pandas, pyarrow]>=3.20.0,<4.0.0
google-cloud-secret-manager==2.26.0
google-cloud-aiplatform==1.137.0
```

> ✅ Why one heavy base?<br/>
Most large deps (e.g., pandas, google-cloud-*) are installed once in base.
Component‑specific images then add only what is strictly needed.

## ➕ Creating a new component image

1. Create a folder under `vertex/docker/<component-image>/`.
2. Add:
    - Dockerfile (should start with FROM <REGISTRY>/base:<tag> after publishing the base once, or FROM base:local for local chained builds).
    - requirements.txt (only extra deps).
    - version.yaml (tags for this image).
    - Makefile (copy from base and adjust IMAGE_NAME).
    - .dockerignore.

## 🚀 Build & publish (make commands)
Prerequisites:

- `gcloud auth login && gcloud auth application-default login`
- Artifact Registry repo exists and Docker is authorized:<br/>`gloud auth configure-docker europe-west9-docker.pkg.dev`

### Build locally (linux/amd64 for Vertex)

List docker images found under `vertex/docker/*`
```bash
   docker-list   
```

Build all docker images
```bash
  docker-build-all   
```

Build one docker image 
```bash
  docker-build IMAGE=<component-image>
```

Release (Build & Push) all docker images
```bash
  docker-release-all   
```

Release (Build & Push) one docker image
```bash
  docker-release IMAGE=<component-image>
```
> 🧱 Architecture: We build for linux/amd64 to match Vertex Pipelines execution.
If you are on Apple Silicon, buildx handles cross‑compilation.

## 🧩 Using images in KFP components
Pin images in code so runs are reproducible:
```python
from kfp import dsl

@dsl.component(
    base_image="europe-west9-docker.pkg.dev/forecast-sales-poc/forecast-sales-images/base:0.1.72",
)
def evaluate(...):
    ...
```
> 🔒 Pin exact tags (e.g., 0.1.72) only for local experiments ; for production pipelines use latest .

## ✅ Best practices

- Keep images immutable: never install with packages_to_install at run time in KFP.
- Small overlays: component images should add minimal extras on top of base.
- Pin versions: both Python packages and image tags (avoid surprise upgrades).
- One purpose per image: do not mix training dependencies into ingestion images.
- Security & size:
    - Use python:*-slim; clean apt lists; --no-cache-dir for pip.
    - Avoid copying repo root; copy only what you need.
    - Use a .dockerignore to keep build contexts lean.
- Performance:
    - Reuse the base layer to speed up pulls.
    - If an image must be large (e.g., heavy ML libs), centralize it in base.

## 🔗 Cross‑references

- [Parameters](../parameters/README.md): How components are configured
- [Components](../pipelines/README.md): How components are organized
- [Pipelines](../pipelines/README.md): How components are orchestrated
- [Shared utilities](../common/README.md): Utilities used by components