# Vertex Pipelines — Definitions & Compiled Templates

This directory contains the **pipeline definitions** and the **compiled templates** used by Vertex AI Pipelines.

> ℹ️ **What lives here**
> - **Python pipeline definitions**: KFP/Vertex pipelines described in code.
> - **Compiled templates**: the compiled artifacts (JSON/YAML) generated from the Python definitions and ready to be submitted to Vertex Pipelines.

## 📂 Directory Structure
```bash
vertex/
└── pipelines/              # Pipeline definitions and templates
    ├── templates/          # Compiled pipeline templates (JSON) ready to submit
    └── README.md           # This guide
```

## 🖥️ Hardware Strategy & Cost Optimization (FinOps)

This project uses **Vertex AI Pipelines (KFP)** to orchestrate containerized steps. To control spend and improve throughput, we enforce a strict **Right‑Sizing** policy: each component requests only the CPU and memory it actually needs.

### How machine sizing works in Vertex Pipelines

Each task declares resource limits in code (e.g., `set_cpu_limit()` and `set_memory_limit()` in KFP). Vertex Pipelines schedules the task onto a **cost‑effective standard machine** that satisfies the requested resources, and you are billed **only for the task’s run time**.

> ℹ️ **Project policy:** We right‑size at the **component level**. If a step needs more CPU/RAM, increase limits for that step only—**do not** upsize the whole pipeline.

### Project baseline (practical minimum)

The KFP runtime introduces pod overhead (init/wait containers, artifact handling). Combined with our heavier images (e.g., ~1.8 GB Prophet), we set a **project baseline** of **2 vCPUs and 8 GB RAM** (roughly `e2-standard-2`) for stability.

> ⚠️ If you request less than this baseline, Kubernetes may place the pod on a **High‑Memory** flavor to stay stable, or you may see **OOM** (Out‑Of‑Memory) or image‑pull slowdowns. Treat **2 vCPU / 8 GB** as the **minimum** for most steps in this starter kit.

### GCP machine family quick guide

| Machine Family | Requested Config (vCPU / RAM) | When to Use (Typical) |
|---|---|---|
| **E2‑Standard‑2** *(Baseline / Light)* | **2 vCPU**, **8 GB RAM** | **Orchestration & light ML**: small DataFrames, steps that delegate heavy work to BigQuery, evaluation/reporting, metadata/registry ops. Cost‑efficient default. |
| **N2‑HighMem** *(Memory‑optimized)* | **2–8 vCPU**, **16–64+ GB RAM** | **RAM bottlenecks**: very large DataFrames in Pandas/Polars or wide feature matrices. Use sparingly to avoid OOM.<br/>**Strategic reserve** — if extractions grow to GiB scale, the split/feature steps may require this. |
| **C2 / E2‑Standard‑8** *(Compute‑optimized)* | **8–16 vCPU**, **32–64 GB RAM** | **CPU‑bound math**: parallelizable algorithms, heavy transforms, or hyperparameter search (Prophet/XGBoost). Cuts hours to minutes. |

### Architectural best practices

1. **Push compute to the warehouse.** Keep extraction components light—let **BigQuery** perform heavy joins/aggregations. The container should mostly **receive results**, not crunch raw data.
2. **Use immutable images.** Avoid `packages_to_install` during runs in production. Pre‑bake dependencies (Prophet, Pandas, etc.) into **Artifact Registry** images to reduce cold‑start time and avoid surprise failures from upstream package changes.
3. **Allocate to the bottleneck.**  
   - **Prophet** is primarily **CPU‑bound** → scale **vCPU**.  
   - **Pandas** is primarily **RAM‑bound** → scale **memory**.  
   Right‑size per step according to the dominant library.

### KFP snippet: setting per‑step limits

```python
from kfp import dsl

@dsl.component(
    base_image="us-docker.pkg.dev/<project>/<repo>/prophet:latest",
    packages_to_install=[],   # Keep empty in prod; use pre-baked images
)
def prophet_train(...):
    # training code
    ...

@dsl.pipeline
def training_pipeline(...):
    train = prophet_train(...)
    # Baseline for light steps (this project’s practical minimum)
    train.set_cpu_limit("2")
    train.set_memory_limit("8G")

    # Example: bump resources for a CPU-bound tuner
    # tuner = prophet_tune(...)
    # tuner.set_cpu_limit("8")
    # tuner.set_memory_limit("32G")
```
## 🔗 Cross‑references

  - [Parameters](../parameters/README.md): How components are configured
  - [Docker images](../docker/README.md): How components run
  - [Components](../pipelines/README.md): How components are organized
  - [Shared utilities](../common/README.md): Utilities used by components