# Parameters — Pipeline Configuration

This directory stores the **parameter sets** that are injected into **Vertex AI / KFP pipelines** and their components.

> ✅ **One folder per pipeline**  
> Create **one subfolder per pipeline** found in `vertex/pipelines/`.  
> Reuse a folder **only** if another pipeline truly shares the exact same parameter schema and defaults (rare).

> 🧩 **Versioning**  
> If you need to evolve a parameter set in a breaking way, version the file name.  
> **Naming convention:** `params_v1.yaml`, `params_v2.yaml`, …


## 🧭 Local vs. CI/CD (automation)

- **Development (local):** keep parameter files **in this repo** under `vertex/parameters/<pipeline>/params_v*.yaml` so you can iterate quickly.
- **Automated runs (CI/CD or CI/CT):** store parameters in a **centralized location** (e.g., **GCS**) and pass a URI at run time.  
  - Example URIs:  
    - Local path: `vertex/parameters/volume_forecast/params_v1.yaml`  
    - GCS path: `gs://my-bucket/parameters/volume_forecast/params_v1.yaml`

- **Do not** store secrets in YAML. Put secrets in **Secret Manager** and reference them by **name** in the params.
params_v2.yaml`).


## 📂 Folder layout (convention)

```bash
vertex/
└── parameters/
    ├── <pipeline_name_a>/
    │   ├── params_v1.yaml
    │   └── params_v2.yaml        # optional (when schema/values change)
    └── <pipeline_name_b>/
        └── params_v1.yaml
```
### Naming rules

- Name the parameter subfolder the same as the **Python pipeline** under `vertex/pipelines/`<br/>
(e.g., `vertex/pipelines/volume_forecast.py` → `/parameters/volume_forecast/params_v1.yaml`).

## ✅ What belongs here (and what does not)

* **Put here:** declarative configuration for pipelines and steps (datasets, table names, hyperparameters, thresholds, display names, registries, etc.).
* **Do not put:** secrets (passwords/tokens). Store secrets in Secret Manager and reference them by name here if needed (e.g., db_password_secret_name: "DB_PASSWORD").
* **Do not put:** executable code; keep logic inside components.

## 🧾 Example parameter file — params_v1.yaml

The blocks below are actions/sections (not function names).<br/>
Reuse values using YAML anchors (&) and aliases (*) where helpful.

```yaml
# ---------- Global identifiers ----------
global_configuration:
  model_name: &model_name "volume-forecast-prophet"

# ---------- Infra / platform context ----------
infra:
  project_id: forecast-sales-poc
  location: europe-west9

# ---------- Training (Prophet) ----------
train_prophet_model:
  hyperparameter_grid:
    changepoint_prior_scale:
      - 0.1
      - 0.5
    seasonality_mode:
      - additive
      - multiplicative
    weekly_seasonality:
      - 5
      - 10

# ---------- Champion vs. challenger gate ----------
gate_champion_vs_challenger:
  model_display_name: *model_name
  champion_label_env: dev

# ---------- Model registration ----------
register_prophet_model:
  model_display_name: *model_name
  serving_image_uri: europe-west9-docker.pkg.dev/forecast-sales-poc/forecast-sales-images/prophet:latest
```


## 🔗 Referencing parameters from code (example)
Below is a minimal pattern to load a parameter set and pass sections to components.
(Adjust paths and mappings to your project structure.)

```python
from pathlib import Path
import yaml

PARAMS_PATH = Path("vertex/parameters/volume_forecast/params_v1.yaml")

with open(PARAMS_PATH, "r") as f:
    cfg = yaml.safe_load(f)

# Examples of section access (as actions/text, not function names)
infra = cfg["infra"]
extract_cfg = cfg["extract_data_from_bq"]
split_cfg = cfg["split_time_series"]
train_cfg = cfg["train_prophet_model"]
eval_cfg = cfg["evaluation_model"]
gate_cfg = cfg["gate_champion_vs_challenger"]
register_cfg = cfg["register_prophet_model"]
```
## 🔗 Cross‑references

  - [Pipelines](../pipelines/README.md): How components are orchestrated
  - [Docker images](../docker/README.md): How components run
  - [Components](../pipelines/README.md): How components are organized
  - [Shared utilities](../common/README.md): Utilities used by components