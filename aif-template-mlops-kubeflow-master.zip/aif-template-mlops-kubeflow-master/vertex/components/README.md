# Components — Reusable building blocks for Vertex Pipelines

This folder contains the **business logic** used by pipelines: ingestion, preprocessing, feature engineering, training, evaluation, governance, and ops/monitoring.

## 📂 Folder structure (convention)

```bash
vertex/
└── components/               # Reusable pipeline components
    ├── data/                 # Data-centric steps
    │   ├── ingest/           # Batch/stream ingestion to raw/staging
    │   ├── preprocess/       # Cleaning, imputation, joins, schema fixes
    │   ├── featurize/        # Feature generation and selection
    │   └── split/            # Train/val/test splitting strategies
    ├── ml/                   # Modeling steps
    │   ├── train/            # Model training routines
    │   ├── evaluate/         # Metrics, validation, reporting
    │   ├── compare/          # Champion/challenger selection
    │   └── refit/            # Refit on full data for production
    ├── governance/           # Model lifecycle governance
    │   └── register/         # Model packaging & registry integration
    └── ops/                  # Operational/infra steps
        └── monitor/          # Data/model monitoring jobs
```

## 🧭 Design principles

- **Single responsibility:** each component does one thing (e.g., “Extract data from BigQuery”, “Split time‑series”, “Evaluate model”).
- **Contracts first:** inputs/outputs are explicit (schemas, paths, artifact types).
- **Config via parameters**: all tunables come from YAML in vertex/parameters/<pipeline>/….
Parameter section names are actions/text (e.g., params_split_time_series), not function names.
- **Immutable runtime:** components run from pre‑built Docker images (see vertex/docker/); avoid installing packages at run time.
- **Right‑sizing:** set per‑component CPU/RAM limits (FinOps) rather than upsizing the whole pipeline.

## ⚙️ Docker images (how components run)

- Reference a pinned image in each component via KFP’s base_image=....
- Prefer one heavy base image with shared deps and small overlays per component (see vertex/docker/).
- Copy only the shared modules you need from vertex/common/core/ into the image.

```python
from kfp import dsl

@dsl.component(
    base_image="europe-west9-docker.pkg.dev/<project>/<repo>/base:0.1.72",  # Pin exact tag for local experiments
)
def evaluate(...):
    ...
```

## 📑  KFP component signature (docstring + types)
```python
from typing import Any, Dict
from kfp import dsl
from kfp.dsl import Input, Output, Dataset, Model, Metrics

PROPHET = "europe-west9-docker.pkg.dev/<project>/<repo>/ml-training:0.2.1"

@dsl.component(base_image=PROPHET)
def prophet_model(
    input_data: Input[Dataset],
    model_output: Output[Model],
    metrics: Output[Metrics],
    infra: Dict[str, Any],
    job_params: Dict[str, Any],
) -> None:
    """
    Trains and tunes a Prophet forecasting candidate model using Time Series Cross Validation.

    This component receives the TRAINING dataset (with the validation gate days already 
    removed). It performs hyperparameter tuning via Grid Search and runs Prophet's native 
    Cross Validation to assess robustness. The best parameters are selected based on the 
    lowest WAPE (Weighted Absolute Percentage Error), which is ideal for volume/logistics. 
    Finally, it trains a candidate model using these best parameters on the provided 
    training data, passing it forward for evaluation against the Champion.

    Args:
        input_data (Input[Dataset]): 
            The training dataset in CSV format (must contain 'ds' and 'y' columns).
        model_output (Output[Model]): 
            The physical artifact path where the candidate JSON model will be stored.
        metrics (Output[Metrics]): 
            The artifact where performance metrics of the candidate model will be logged.
        infra (Dict[str, Any]): 
            Global infrastructure configuration (project_id, location).
        job_params (Dict[str, Any]): 
            Pipeline and algorithm parameters including the hyperparameter grid.

    Returns:
        None.
    """
    ...

```


## 🔗 Cross‑references

  - [Parameters](../parameters/README.md): How components are configured
  - [Docker images](../docker/README.md): How components run
  - [Pipelines](../pipelines/README.md): How components are orchestrated
  - [Shared utilities](../common/README.md): Utilities used by components