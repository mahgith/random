import typer
from pathlib import Path
import os
from datetime import datetime, timezone, timedelta

# Initialize the Typer application
app = typer.Typer(help="CLI for managing predictive model scenarios")

# Define constants at the module level (Global scope)
PROJECT_ID = "forecast-sales-poc"
LOCATION = "europe-west9"
BUCKET_NAME = "volume-forecast-demo"
MODEL_NAME = "volume-forecast-prophet"
DATASET_NAME = "volume_forecast_per_day" 
GROUND_TRUTH_TABLE = "volumes_per_day"
FORECAST_TABLE = "volume_predictions" 
MLOPS_DRIFT_ALERTS = "mlops_drift_alerts"
VOLUME_DRIFT_RADAR = "vw_model_drift_radar"

TABLE_VOLUMES_PER_DAY = f"{PROJECT_ID}.{DATASET_NAME}.{GROUND_TRUTH_TABLE}"
TABLE_VOLUME_PREDICTIONS = f"{PROJECT_ID}.{DATASET_NAME}.{FORECAST_TABLE}"
TABLE_MLOPS_DRIFT_ALERTS = f"{PROJECT_ID}.{DATASET_NAME}.{MLOPS_DRIFT_ALERTS}"
VW_VOLUME_DRIFT_RADAR = f"{PROJECT_ID}.{DATASET_NAME}.{VOLUME_DRIFT_RADAR}"

############################################
# --- Helper Functions ---
############################################

def load_yaml_params_from_gcs(bucket_name: str, blob_name: str) -> dict:
    """Downloads a YAML file from GCS and returns it as a Python dictionary."""
    import yaml
    from google.cloud import storage

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    
    if not blob.exists():
        raise FileNotFoundError(f"Parameters file gs://{bucket_name}/{blob_name} does not exist.")
        
    yaml_content = blob.download_as_string()
    return yaml.safe_load(yaml_content)

def check_gcs_file_exists(bucket_name: str, blob_name: str) -> bool:
    """Verifies if a specific blob exists within a given GCS bucket."""
    from google.cloud import storage

    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    return blob.exists()

def check_drift_and_retrain():
    """
    Evaluates the global model health view and triggers a Vertex AI 
    retraining pipeline if a CRITICAL state is detected.
    """
    from google.cloud import bigquery
    from google.cloud import aiplatform

    typer.echo("\n" + "="*75)
    typer.secho("🤖 Evaluating Global Model Health for Auto-Retraining...", fg=typer.colors.CYAN, bold=True)
    typer.echo("="*75)

    try:
        # Initialize BigQuery client
        bq_client = bigquery.Client(project=PROJECT_ID)
        
        # Query the global health traffic light in BigQuery
        typer.echo("📊 Querying vw_global_model_health...")
        query = f"""
            SELECT global_status
            FROM `{PROJECT_ID}.{DATASET_NAME}.vw_global_model_health`
        """
        
        query_job = bq_client.query(query)
        results = query_job.result()
        
        status = ""
        for row in results:
            status = row.global_status
            
        typer.secho(f"🚦 Current model status: {status}")
            
        # Trigger retraining if health is critical
        if "CRITICAL" in status:
            typer.secho("🚨 Critical alert confirmed. Initiating Vertex AI retraining sequence...", fg=typer.colors.RED, bold=True)

            # Validate and download configuration files
            params_blob_path = "parameters/params_v1.yaml"
            if not check_gcs_file_exists(BUCKET_NAME, params_blob_path):
                typer.secho(f"❌ Pre-check failed: gs://{BUCKET_NAME}/{params_blob_path} not found.", fg=typer.colors.RED, err=True)
                return

            typer.echo("📥 Downloading job_params from GCS...")
            full_params = load_yaml_params_from_gcs(BUCKET_NAME, params_blob_path)
            
            infra = full_params.get("infra", {})
            params_extract_data_from_bq = full_params.get("params_extract_data_from_bq", {})
            params_split_time_series = full_params.get("params_split_time_series", {})
            params_train_prophet_model = full_params.get("params_train_prophet_model", {})
            params_evaluation_model = full_params.get("params_evaluation_model", {})
            params_gate_champion_vs_challenger = full_params.get("params_gate_champion_vs_challenger", {})
            params_register_prophet_model = full_params.get("params_register_prophet_model", {})    

            # Parameter definition (Reminder: There can be as many job_params as components in the pipeline)
            parameter_values = {
                "infra": infra,
                "params_extract_data_from_bq": params_extract_data_from_bq,
                "params_split_time_series": params_split_time_series,
                "params_train_prophet_model": params_train_prophet_model,
                "params_evaluation_model": params_evaluation_model,
                "params_gate_champion_vs_challenger": params_gate_champion_vs_challenger,
                "params_register_prophet_model": params_register_prophet_model
            }

            # Generate a deterministic ID based on the current hour to prevent duplicate runs
            fecha_hora = datetime.now().strftime("%Y%m%d-%H%M")
            job_id_unico = f"auto-retrain-{fecha_hora}"
                
            # Initialize Vertex AI
            typer.echo(f"☁️  Initializing Vertex AI in region {LOCATION}...")
            aiplatform.init(project=PROJECT_ID, location=LOCATION)
            
            # Check for already running pipelines to prevent concurrent executions
            all_recent_jobs = aiplatform.PipelineJob.list(
                filter='display_name="auto-retrain-volume-forecast"',
                order_by="create_time desc"
            )
            recent_jobs = all_recent_jobs[:3]
            
            for job in recent_jobs:
                if "RUNNING" in str(job.state) or "PENDING" in str(job.state):
                    typer.secho(f"✋ Notice: A retraining pipeline ({job.name}) is ALREADY RUNNING. Skipping new execution.", fg=typer.colors.YELLOW)
                    return

            typer.echo("⚙️  Configuring the pipeline execution...")
            pipeline_job = aiplatform.PipelineJob(
                display_name="auto-retrain-volume-forecast",
                # NOTE: Ensure you replace 'latest' with your specific hash or tag if needed
                template_path=f"https://{LOCATION}-kfp.pkg.dev/{PROJECT_ID}/demo-forecast-volume/forecast-volume/latest",
                pipeline_root=f"gs://{BUCKET_NAME}/pipeline_artifacts",
                parameter_values=parameter_values,
                enable_caching=False,
                job_id=job_id_unico 
            )
            
            # Execute the pipeline
            typer.echo("🚀 Submitting the pipeline to Vertex AI...")
            
            # Define target service account
            vertex_service_account = f"461016605441-compute@developer.gserviceaccount.com"
            
            pipeline_job.submit(service_account=vertex_service_account)
            
            typer.echo("\n" + "="*55)
            typer.secho("✅ RETRAINING PIPELINE SUBMITTED SUCCESSFULLY", fg=typer.colors.GREEN, bold=True)
            typer.echo("="*55)
            typer.secho(f" 🔹 Job ID: {job_id_unico}", fg=typer.colors.WHITE)
            typer.secho(f" 🔹 Status: Check Vertex AI Console", fg=typer.colors.WHITE)
            typer.echo("="*55 + "\n")

        else:
            typer.secho("✅ Model passed the Ground Truth evaluation. No retraining required.", fg=typer.colors.GREEN)

    except Exception as e:
        typer.secho(f"❌ Execution Error in check_drift_and_retrain: {str(e)}", fg=typer.colors.RED, bold=True, err=True)


def check_yoy_forecast_drift():
    """
    Evaluate Year-over-Year (YoY) seasonality drift for pending forecast 

    This function retrieves all future predictions lacking ground truth and compares
    their statistical distribution against the actual volume from exactly 52 weeks ago
    using a two-sample Kolmogorov-Smirnov test. The resulting p-value and alert status are
    then appended to a BigQuery monitoring table to drive a Looker Studio dashboard. 
    """
    import pandas as pd
    import numpy as np
    from scipy.stats import ks_2samp
    from google.cloud import bigquery
    from google.api_core.exceptions import GoogleAPIError, NotFound

    typer.echo("\n" + "="*75)
    typer.echo("⚙️  Starting check yoy forecast drift...")
    typer.echo("="*75)

    # Initialize the BigQuery client
    client = bigquery.Client(project=PROJECT_ID)

    typer.echo("🔍 Searching for the predictions without ground truth...")

    # Retrieve the predictions without volumes
    try:
        query_forecast = f"""
            SELECT target_date, predicted_volume
            FROM `{VW_VOLUME_DRIFT_RADAR}`
            WHERE volume IS NULL
            ORDER BY target_date ASC
        """
        df_future = client.query(query_forecast).result().to_dataframe(create_bqstorage_client=False)

    except NotFound:
        typer.secho("⚠️  Forecast table not found.", fg=typer.colors.RED, bold=True, err=True)        
        return
    except GoogleAPIError as e:
        typer.secho(f"⚠️  BigQuery API error reading forecast table: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)  

    # Prevent execution if there are no future predictions available
    if df_future.empty:
        typer.echo("ℹ️  No future predictions found to evaluate")
        return          

    # Extract the earliest and latest dates from the forecast horizon
    forecast_start = df_future['target_date'].min()
    forecast_end = df_future['target_date'].max()

    # Shift dates back by exactly fifty-two weeks to align weekdays
    historical_start = forecast_start - timedelta(days=364)
    historical_end = forecast_end - timedelta(days=364)

    typer.secho(f"📅 Shift dates back by exactly fifty-two weeks to align weekdays from: {historical_start} to {historical_end}", fg=typer.colors.CYAN)

    typer.echo("🔍 Searching for the history data...")

    try:
        query_history = f"""
            SELECT target_date, volume
            FROM `{TABLE_VOLUMES_PER_DAY}`
            WHERE target_date BETWEEN '{historical_start}' AND '{historical_end}'
              AND volume IS NOT NULL
            ORDER BY target_date ASC
        """
        df_history = client.query(query_history).result().to_dataframe(create_bqstorage_client=False)

    except NotFound:
        typer.secho("⚠️  History table not found.", fg=typer.colors.RED, bold=True, err=True)        
        return
    except GoogleAPIError as e:
        typer.secho(f"⚠️  BigQuery API error reading history table: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)  

    # Prevent execution if historical data is missing for the target window
    if df_history.empty:
        typer.echo("ℹ️  No historical data found for the Year-over-Year comparison.")
        return
    
    # Isolate the arrays for the statistical test
    predicted_window = df_future['predicted_volume'].values
    historical_window = df_history['volume'].values

    # Calculating the growth factor
    future_mean = np.mean(predicted_window)
    past_mean = np.mean(historical_window)
    if past_mean > 0:
        scaling_factor = future_mean / past_mean
    else:
        scaling_factor = 1.0
    scaled_historical_windows = historical_window * scaling_factor

    typer.echo("🧠 Running the Kolmogorov-Smirnov test on predictions and historical data...")

    try:
        # Run the Kolmogorov-Smirnov test on both arrays
        ks_statistic, p_value = ks_2samp(predicted_window, scaled_historical_windows)

        # Evaluate the p-value against the standard significance threshold
        is_drifting = p_value < 0.05
        status_label = '🚨 SEASONALITY DRIFT' if is_drifting else '✅ HEALTHY FORECAST'
    except ValueError as e:
        typer.secho("❌ Math error: Failed to compute KS Test.", fg=typer.colors.RED, bold=True, err=True)  
        return
    except Exception as e: 
        typer.secho("❌ Unexpected error.", fg=typer.colors.RED, bold=True, err=True) 
        return

    # Print the logic to terminal for debugging and logging
    typer.echo("\n" + "="*75)
    typer.secho("📊 Proactive YoY Drift Report", fg=typer.colors.CYAN, bold=True)
    typer.echo("="*75)
    typer.echo(f"Comparing Forecast ({forecast_start} to {forecast_end})")
    typer.echo(f"Against Reality ({historical_start} to {historical_end})")
    
    # Color coding the status label
    if is_drifting:
        typer.secho(f"Status: {status_label} (P-Value: {p_value:.4f})", fg=typer.colors.RED, bold=True)
    else:
        typer.secho(f"Status: {status_label} (P-Value: {p_value:.4f})", fg=typer.colors.GREEN, bold=True)
    typer.echo("") 

    # Prepare the record to be inserted into the BigQuery alerts table
    test_execution_date = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    
    row_to_insert = [
        {
            "test_date": test_execution_date,
            "p_value": float(p_value),
            "ks_statistic": float(ks_statistic),
            "alert_status": status_label,
            "test_type": "YoY_Forecast_vs_Reality"
        }
    ]
    
    try:
        # Insert the row into the BigQuery alerts table
        errors = client.insert_rows_json(TABLE_MLOPS_DRIFT_ALERTS, row_to_insert)
        if errors == []:
            typer.secho("💾 Alert successfully saved to BigQuery.", fg=typer.colors.GREEN) 
        else:
            typer.secho(f"⚠️ Errors occurred while saving to BigQuery: {errors}", fg=typer.colors.YELLOW)

    except GoogleAPIError as e:
        typer.secho(f"❌ BigQuery API error writing table: {e}", fg=typer.colors.RED, bold=True, err=True)
    except Exception as e:
        typer.secho(f"❌ Error writing predictions to BigQuery: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)        


############################################
# --- Typer Commands ---
############################################

@app.command(name="initial-load")
def initial_load():
    """
    Initial load of ground truth data from a CSV file for demo purposes.
    This populates the baseline data used for model training.
    It will DELETE all existing data in the table before loading the CSV.
    """
    import pandas as pd
    from google.cloud import bigquery

    typer.echo("\n" + "="*75)
    typer.echo("⚙️  Starting initial data load...")
    typer.echo("="*75)

    typer.echo("📂 Locating training baseline data...")
    
    # Resolve path to the example data directory
    base_path = Path(__file__).parent
    csv_path = base_path / "example_data" / "demand_training_baseline.csv"

    if not csv_path.exists():
        typer.secho(f"❌ CSV file not found at: {csv_path}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    try:
        # Load CSV into DataFrame
        typer.echo(f"📖 Reading CSV file: {csv_path.name}...")
        df = pd.read_csv(csv_path)

        # Ensure the columns match the BigQuery schema
        df = df.rename(columns={'date': 'target_date'})
        df['target_date'] = pd.to_datetime(df['target_date']).dt.date

        typer.echo(f"📊 Processed {len(df)} rows. Preparing for BigQuery upload...")

        # Initialize BigQuery Client
        client = bigquery.Client(project=PROJECT_ID)

        # Configure initial load to overwrite existing baseline
        job_config = bigquery.LoadJobConfig(
            write_disposition="WRITE_TRUNCATE",
        )

        typer.echo(f"✨ Resetting table and uploading data to {GROUND_TRUTH_TABLE}...")
        
        load_job = client.load_table_from_dataframe(
            df, 
            TABLE_VOLUMES_PER_DAY, 
            job_config=job_config
        )
        load_job.result()  

        typer.echo("\n" + "="*55)
        typer.secho("🚀 GROUND TRUTH RESET AND LOADED SUCCESSFULLY", fg=typer.colors.GREEN, bold=True)
        typer.echo("="*55)
        typer.secho(f" 🔹 Table: {GROUND_TRUTH_TABLE}", fg=typer.colors.WHITE)
        typer.secho(f" 🔹 Action: Deleted existing data & inserted {len(df)} rows", fg=typer.colors.WHITE)
        typer.secho(f" 🔹 Source: {csv_path.name}", fg=typer.colors.WHITE)
        typer.echo("="*55 + "\n")

    except Exception as e:
        typer.secho(f"❌ Error during ground truth loading: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)

@app.command(name="clear")
def clear():
    """
    Clears the data for the current scenario.
    Deletes all predictions and actual volumes starting from 2024-07-02.
    """
    from google.cloud import bigquery

    typer.echo("\n" + "="*75)
    typer.echo("⚙️  Starting scenario cleanup...")
    typer.echo("="*75)

    client = bigquery.Client(project=PROJECT_ID)

    query_clear_volumes = f"DELETE FROM `{TABLE_VOLUMES_PER_DAY}` WHERE target_date >= '2024-07-02';"
    query_clear_predictions = f"TRUNCATE TABLE `{TABLE_VOLUME_PREDICTIONS}`;"
    query_clear_mlops_drift_alerts = f"TRUNCATE TABLE `{TABLE_MLOPS_DRIFT_ALERTS}`;"
    
    try:
        typer.echo("🧹 Cleaning up ground truth data starting from July 2nd...")
        client.query(query_clear_volumes).result()
        typer.secho(f"✅ Data from `{TABLE_VOLUMES_PER_DAY}` deleted.", fg=typer.colors.GREEN)

        typer.echo("🧹 Cleaning up predictions data...")
        client.query(query_clear_predictions).result()
        typer.secho(f"✅ Data from `{TABLE_VOLUME_PREDICTIONS}` deleted.", fg=typer.colors.GREEN)

        typer.echo("🧹 Cleaning up mlops drift alerts...")
        client.query(query_clear_mlops_drift_alerts).result()
        typer.secho(f"✅ Data from `{TABLE_MLOPS_DRIFT_ALERTS}` deleted.", fg=typer.colors.GREEN)        

        typer.echo("\n" + "="*75)
        typer.secho("🚀 SCENARIO SUCCESSFULLY RESET", fg=typer.colors.GREEN, bold=True)
        typer.echo("="*75)
        typer.secho("📊 Current Database Status:", fg=typer.colors.CYAN, bold=True)
        typer.secho(f" 🔹 The '{GROUND_TRUTH_TABLE}' table now only contains data up to 2024-07-01.", fg=typer.colors.WHITE)
        typer.secho(f" 🔹 The '{FORECAST_TABLE}' table is completely empty.", fg=typer.colors.WHITE)
        typer.secho(" 🔹 Consequently, the main view is clean and has no forecast data.", fg=typer.colors.WHITE)
        typer.echo("="*75 + "\n")
        
    except Exception as e:
        typer.secho(f"❌ Error clearing the scenario: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)
    

@app.command(name="prediction")
def prediction(
    forecast_days: int = typer.Option(5, "--days", "-d", help="Number of days to forecast into the future")
):
    """
    Executes batch prediction by retrieving the Champion model from Vertex AI.
    Calculates the start date by first querying the forecast table, then the ground truth.
    """
    import pandas as pd
    from google.cloud import bigquery
    from google.cloud import aiplatform
    from google.cloud import storage
    from google.api_core.exceptions import GoogleAPIError, NotFound
    from prophet.serialize import model_from_json

    typer.echo("\n" + "="*75)
    typer.echo("⚙️  Starting batch predictions...")
    typer.echo("="*75)

    # Initialize GCP Clients
    try:
        aiplatform.init(project=PROJECT_ID, location=LOCATION)
        bq_client = bigquery.Client(project=PROJECT_ID)
        storage_client = storage.Client(project=PROJECT_ID)
    except Exception as e:
        typer.echo(f"❌ Failed to initialize GCP clients: {e}", err=True)
        raise typer.Exit(code=1)

    typer.echo("🔍 Searching for the Champion model in Vertex AI Registry...")

    # Retrieve the current Champion model using metadata labels
    try:
        models = aiplatform.Model.list(
            filter=f'labels.role="champion" AND display_name="{MODEL_NAME}"'
        )
    except GoogleAPIError as e:
        typer.secho(f"❌ Vertex AI API error while searching for models: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)            

    if not models:
        typer.secho("❌ No champion model found! Ensure your pipeline labels the winner correctly.", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1) 

    champion_model = models[0]
    typer.secho(f"🏆 Champion found: version_id={champion_model.version_id}, uri={champion_model.uri}", fg=typer.colors.CYAN)    

    # Download the physical model artifact from GCS
    uri_parts = champion_model.uri.replace("gs://", "").split("/")
    bucket_name = uri_parts[0]
    prefix = "/".join(uri_parts[1:]) + "/model.json"      

    typer.echo(f"📥 Downloading model artifact from GCS... bucket={bucket_name}, file={prefix}")
    try:
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(prefix)
        model_json_string = blob.download_as_string()    

        # Load Prophet model into memory for inference
        model = model_from_json(model_json_string) 
    except NotFound:
        typer.secho(f"❌ Model file not found in GCS at {champion_model.uri}/model.json", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
    except Exception as e:
        typer.secho(f"❌ Failed to download or load the Prophet model: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)               

    # Evaluate date logic starting from predictions to ground truth to current date
    last_date = pd.NaT

    typer.echo("📅 Checking the maximum date in the forecast table...")
    try:
        query_forecast = f"""
            SELECT MAX(target_date) as last_date 
            FROM `{TABLE_VOLUME_PREDICTIONS}`
        """
        # Disable BigQuery Storage API client to avoid warnings
        result_forecast = bq_client.query(query_forecast).result().to_dataframe(create_bqstorage_client=False)
        if not result_forecast.empty and not pd.isnull(result_forecast['last_date'].iloc[0]):
            last_date = result_forecast['last_date'].iloc[0]
            typer.secho(f"✅ Last prediction date found: {last_date}", fg=typer.colors.GREEN)
    except NotFound:
        typer.secho("⚠️ Forecast table not found (normal for first run).", fg=typer.colors.YELLOW)
    except GoogleAPIError as e:
        typer.secho(f"⚠️ BigQuery API error reading forecast table: {e}", fg=typer.colors.RED, err=True)

    # If the forecast table does not exist or is empty, check Ground Truth
    if pd.isnull(last_date):
        typer.echo("🗄️  Querying BigQuery for the latest date in Ground Truth...")
        try:
            query_truth = f"""
                SELECT MAX(target_date) as last_date 
                FROM `{TABLE_VOLUMES_PER_DAY}`
            """
            result_truth = bq_client.query(query_truth).result().to_dataframe(create_bqstorage_client=False)
            if not result_truth.empty and not pd.isnull(result_truth['last_date'].iloc[0]):
                last_date = result_truth['last_date'].iloc[0]
                typer.secho(f"✅ Last Ground Truth date found: {last_date}", fg=typer.colors.GREEN)
        except NotFound:
            typer.secho("⚠️ Ground Truth table not found.", fg=typer.colors.RED, err=True)
        except GoogleAPIError as e:
            typer.secho(f"⚠️ BigQuery API error reading Ground Truth table: {e}", fg=typer.colors.RED, err=True)
    
    # Fix for datetime deprecation by enforcing timezone.utc
    if pd.isnull(last_date):
        last_date = datetime.now(timezone.utc).date()
        typer.secho(f"⏱️ No previous dates found. Using current UTC date as base: {last_date}", fg=typer.colors.YELLOW)

    typer.echo(f"🔮 Generating predictions for the next {forecast_days} days starting from {last_date + pd.Timedelta(days=1)}.")                

    # Generate future prediction horizon
    future_dates = pd.date_range(
        start=last_date + pd.Timedelta(days=1), 
        periods=forecast_days
    )
    df_future = pd.DataFrame({'ds': future_dates})

    # Execute model inference
    typer.echo("🧠 Executing Prophet model inference...")
    try:
        forecast = model.predict(df_future)
    except Exception as e:
        typer.secho(f"❌ Error during model inference: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)

    # Format results for the BigQuery prediction table schema
    results_df = pd.DataFrame({
        'prediction_date': datetime.now(timezone.utc).date(),
        'target_date': forecast['ds'].dt.date,
        'predicted_volume': forecast['yhat'],
        'yhat_lower': forecast['yhat_lower'],
        'yhat_upper': forecast['yhat_upper'],
        'model_version': champion_model.version_id
    })

    # Calculate the prediction uncertainty
    results_df['relative_uncertainty_pct'] = (results_df['yhat_upper'] - results_df['yhat_lower']) / results_df['predicted_volume']

    # Data Ingestion into BigQuery
    typer.echo(f"☁️  Uploading predictions to {FORECAST_TABLE}...")

    try:
        job_config = bigquery.LoadJobConfig(write_disposition="WRITE_APPEND")
        load_job = bq_client.load_table_from_dataframe(
            results_df, 
            TABLE_VOLUME_PREDICTIONS,
            job_config=job_config
        )
        load_job.result() # Wait for job completion
        typer.echo("\n" + "="*75)
        typer.secho(f"🚀 SUCCESS! {len(results_df)} rows inserted into {FORECAST_TABLE}.", fg=typer.colors.GREEN, bold=True)
        typer.echo("="*75 + "\n")

    except Exception as e:
        typer.secho(f"❌ Error writing predictions to BigQuery: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)

    # Run the drift assessment immediately after loading new data
    check_yoy_forecast_drift()

@app.command(name="feed-volumes")
def feed_volumes(
    scenario: str = typer.Argument(..., help="Scenario to simulate: 'stable', 'data-drift', or 'concept-drift'"),
    days: int = typer.Option(5, "--days", "-d", help="Number of days to append to ground truth")
):
    """
    Simulates real-world data ingestion by appending N days of data from a specific scenario CSV.
    It looks for the last existing date in BigQuery and takes the next available days from the source.
    """
    import pandas as pd
    from google.cloud import bigquery
    
    typer.echo("\n" + "="*75)
    typer.secho(f"⚙️  Starting feed volumes for scenario: {scenario.upper()}", fg=typer.colors.CYAN, bold=True)
    typer.echo("="*75)

    # Map scenarios to file names
    scenario_files = {
        "stable": "demand_eval_stable_scenario.csv",
        "data-drift": "demand_eval_data_drift.csv",
        "concept-drift": "demand_eval_concept_drift.csv"
    }

    if scenario not in scenario_files:
        typer.secho(f"❌ Invalid scenario: '{scenario}'. Choose from: stable, data-drift, concept-drift", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)
   
    # Resolve path to the example data directory
    base_path = Path(__file__).parent
    csv_path = base_path / "example_data" / scenario_files[scenario]

    if not csv_path.exists():
        typer.secho(f"❌ Scenario file not found at: {csv_path}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1)

    client = bigquery.Client(project=PROJECT_ID)

    try:
        # Retrieve the most recent date available in BigQuery
        typer.echo(f"📅 Checking current progress in {GROUND_TRUTH_TABLE}...")
        query = f"SELECT MAX(target_date) as last_date FROM `{TABLE_VOLUMES_PER_DAY}`"
        query_job = client.query(query)
        result = query_job.result().to_dataframe()
        last_date = result['last_date'].iloc[0]

        if pd.isnull(last_date):
            # Fallback to the original baseline cutoff if table is empty
            last_date = pd.to_datetime("2024-07-01").date()
            typer.secho(f"⚠️ Table is empty. Starting from baseline end: {last_date}", fg=typer.colors.YELLOW)
        else:
            typer.secho(f"✅ Last date in BigQuery: {last_date}", fg=typer.colors.GREEN)

        # Load scenario data from CSV and filter by target date
        typer.echo(f"📖 Reading scenario data: {scenario_files[scenario]}...")
        df_scenario = pd.read_csv(csv_path)
        
        # Align column schema for dates
        df_scenario = df_scenario.rename(columns={'date': 'target_date'})
        df_scenario['target_date'] = pd.to_datetime(df_scenario['target_date']).dt.date

        # Filter strictly for upcoming dates
        df_to_load = df_scenario[df_scenario['target_date'] > last_date].sort_values('target_date')

        if df_to_load.empty:
            typer.secho(f"🛑 No more new dates found in {scenario_files[scenario]} after {last_date}.", fg=typer.colors.YELLOW)
            raise typer.Exit()

        # Take only the requested number of days
        if len(df_to_load) < days:
            typer.secho(f"⚠️ Only {len(df_to_load)} days remaining in the file. Loading all of them.", fg=typer.colors.YELLOW)
            days = len(df_to_load)

        df_final = df_to_load.head(days)
        start_date = df_final['target_date'].min()
        end_date = df_final['target_date'].max()

        typer.echo(f"📤 Appending {days} days of data ({start_date} to {end_date}) to {GROUND_TRUTH_TABLE}...")
        
        job_config = bigquery.LoadJobConfig(write_disposition="WRITE_APPEND")
        load_job = client.load_table_from_dataframe(
            df_final, 
            TABLE_VOLUMES_PER_DAY, 
            job_config=job_config
        )
        load_job.result()

        typer.echo("\n" + "="*55)
        typer.secho(f"🚀 REALITY SIMULATED: {scenario.upper()}", fg=typer.colors.GREEN, bold=True)
        typer.echo("="*55)
        typer.secho(f" 🔹 New dates added: {days}", fg=typer.colors.WHITE)
        typer.secho(f" 🔹 Time range: {start_date} to {end_date}", fg=typer.colors.WHITE)
        typer.secho(f" 🔹 Mode: WRITE_APPEND", fg=typer.colors.WHITE)
        typer.echo("="*55 + "\n")

    except Exception as e:
        typer.secho(f"❌ Error during simulation: {e}", fg=typer.colors.RED, bold=True, err=True)
        raise typer.Exit(code=1)
        
    # Finally, evaluate if retraining is necessary
    check_drift_and_retrain()

if __name__ == "__main__":
    app()