# Demo — Quick Guide

This `demo/` folder contains **lightweight, end‑to‑end examples** that mirror the project structure and show how pipelines are wired together.  
> ⚠️ **Illustrative examples. NOT for production.** Harden components (validation, retries, observability, security) before using in real workloads.

There are **two demo pipelines**:

1) **Volume forecast** — time‑series forecasting with Prophet, champion‑challenger gate, and model registration.  
2) **Preprocessing volume forecast** — raw CSV ingestion → cleaning/merging → feature engineering → (example) data‑drift evaluation.

---

## 📍 Where things live (by pipeline)

### 1) Volume forecast

- **Definition (KFP):** `demo/vertex/pipelines/volume_forecast.py`
  - Imports demo components:
    ```python
    from components.data.ingest.volume_forecast import extract_data_from_bq
    from components.data.split.volume_forecast import split_time_series_data
    from components.ml.train.volume_forecast import prophet_model
    from components.ml.evaluate.volume_forecast import evaluate_prophet_model
    from components.ml.compare.volume_forecast import gate_champion_vs_challenger
    from components.ml.refit.volume_forecast import refit_prophet_model
    from components.governance.register.volume_forecast import register_prophet_model
    ```
- **Compiled template (JSON):** `demo/vertex/pipelines/templates/volume_forecast.json`
- **Parameters (YAML):** `demo/vertex/parameters/volume_forecast/params_v1.yaml`
  - `infra` — global platform context (project_id, location, bucket_name)  
  - `params_*` — action‑based blocks for each step (e.g., `params_train_prophet_model`)
- **Local deploy script (dev):** `demo/vertex/deploy_volume_forecast.py` *(name inferred from snippet; if you keep a single deploy, note its path here)*  
  - Compiles to JSON and **submits the job to Vertex AI**, loading params with:
    ```python
    full_params = load_kfp_params("volume_forecast", "params_v1")
    ```
- **Common utilities used by the demo:** `demo/vertex/common/core/*` (logger, params loader, etc.)
- **Images:** components pin images built from `vertex/docker/*` (see Docker README)
- **CLI demo:** CLI for client workshops, keep it here (e.g., demo/cli_demo.py) to simulate scenarios such as:
  - Trigger a backfill run
  - Generate synthetic data
  - Force thresholds to fail and observe gates/alerts

### 2) Preprocessing volume forecast

- **Definition (KFP):** `demo/vertex/pipelines/my_first_pipeline.py`
  - Imports demo components:
    ```python
    from components.data.ingest.csv_to_bigquery import ingest_csv_to_bigquery
    from components.data.preprocess.clean_and_merge_tables import clean_and_merge_tables
    from components.data.featurize.build_training_dataset import build_training_dataset
    from components.ops.monitor.data_drift import data_drift_evaluation
    # from components.ml.train.model import train_xgboost_model
    ```
- **Compiled template (JSON):** `demo/vertex/pipelines/templates/my_first_pipeline.json`
- **Parameters (YAML):** `demo/vertex/parameters/my_first_pipeline/params_v1.yaml`
  - `infra` — global platform context  
  - `params_ingestion_shipments`, `params_ingestion_events`, `params_clean_and_merge_tables`, `params_build_training_dataset`  
  - *(Optional)* `params_train_xgboost_model` if you enable that step
- **Local deploy script (dev):** `demo/vertex/deploy_my_first_pipeline.py`
  - Compiles/submits using:
    ```python
    full_params = load_kfp_params("my_first_pipeline", "params_v1")
    ```
- **Images:** same principle — pin component images from `vertex/docker/*`

